module.exports = {
    database:'mongodb://root:abc123@ds145325.mlab.com:45325/weigo_animation',
    port:3000,
    secretKey:'Weigo@$@!#@'
};
